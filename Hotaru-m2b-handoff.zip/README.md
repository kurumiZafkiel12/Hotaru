# Hotaru · 蛍

一点微光，自在连接。

独立开发中的 Mihomo 客户端：小组件首页、网络工具箱与多跳代理。Windows 10/11 x64 优先，后续 Android、Linux。

**当前提供未签名的 Windows 原生界面预览包（`apps/hotaru`），不是可用代理客户端；不含 Mihomo 二进制，未启用系统代理或 TUN。**

## 当前状态与已实现能力

### 1. 正式原生工程（`apps/hotaru`，Flutter 3.47.8 / Dart 3.13.7）
- **桌面小组件首页（`lib/dashboard.dart`）**：深色萤光主题，支持小组件添加、移除、拖动排序、恢复默认，以及基于临时文件原子替换的本地布局持久化（Windows `%APPDATA%/Hotaru/layout-v1.json`，不保存任何节点凭据）。
- **网络工具箱与内核诊断入口**：工具箱明确展示未接入状态（不生成虚假测速或模拟 IP）；桌面内核诊断页（`lib/main.dart` + `lib/core/mihomo_controller.dart`）支持配置校验、子进程启动、控制端口冲突自动回退分配、随机密钥 `/version` 认证健康检查、返回导航/销毁/退出自动停止与临时文件清理。
- **订阅与单节点导入预览（`lib/profiles/importer.dart`、`lib/profiles/import_page.dart`）**：支持显式 `proxies` 的 Mihomo YAML/JSON、SOCKS5/HTTP(S)/基础 Trojan URI（仅支持 `sni` 参数，未知参数或空参数明确拒绝），以及带 10 秒连接超时、20 秒总超时、2 MiB 上限且不自动跟随重定向的 HTTPS 订阅下载。提供“仅导入节点”与“完整配置”两种结构检查模式。**当前仅在内存中预览校验，尚不保存、不应用配置。**

### 2. 早期网页原型（仓库根目录 `src/`）
- Vite 交互原型，用于早期桌面卡片、工具箱与多跳路径草稿交互参考。正式产品迭代以 `apps/hotaru/` 为准。

## 尚未实现（后续阶段）
- **完整订阅管理与安全存储**：解析候选模型、语义校验、原始订阅与用户覆写分离、原子保存与失败回滚。
- **扩展协议与格式**：SS、VMess、VLESS、Hysteria2 等 URI，Base64 订阅与远程 `proxy-providers`。
- **实际代理闭环与系统集成**：节点选择、Mihomo 运行配置生成、HTTP/SOCKS 本地代理入口、系统代理、TUN、域名/IP/应用分流、延迟与下载测速、免费来源 IP 质量检测、多跳代理（`dialer-proxy`）、连接记录、流量统计、系统托盘与开机启动。

详细计划与文档：[开发计划](docs/PLAN.md) · [架构边界](docs/ARCHITECTURE.md) · [M1 验证记录](docs/M1-VERIFICATION.md) · [M2 导入说明](docs/M2-IMPORT.md) · [本轮交接报告](docs/HANDOFF-REPORT.md)。

## 下载与运行 Windows 预览
`main` 分支的 Windows CI 工作流在静态检查、测试和 Release 编译通过后，自动发布附带 SHA256 的预发布 ZIP，见 [Releases](https://github.com/kurumiZafkiel12/Hotaru/releases)。
- 下载后请**完整解压整个 ZIP 目录**，再运行其中的 `hotaru.exe`（不要单独移动或复制 `hotaru.exe`）。
- 产物为未签名开发预览，不含 Mihomo 内核，不会修改系统代理或网卡设置。

## 本地开发与自检命令

### 原生工程（`apps/hotaru`）
```sh
cd apps/hotaru
flutter pub get
dart format lib test tool
flutter analyze
flutter test
flutter build windows --release
```

本机真实 Mihomo 诊断冒烟测试：
```sh
cd apps/hotaru
dart run tool/core_smoke.dart <Mihomo可执行文件绝对路径>
```

### 网页原型（仓库根目录）
需要 Node.js 22.12+（CI 使用 24）：
```sh
npm ci
npm run check
npx playwright install chromium
npx playwright test
```

## 参考与许可
[Mihomo](https://github.com/MetaCubeX/mihomo) 为唯一确定的计划内核（当前仓库与预览产物均未分发 Mihomo 二进制）；[FlClash](https://github.com/chen08209/FlClash)、[Bettbox](https://github.com/appshubcc/Bettbox)、[Clash Verge Rev](https://github.com/clash-verge-rev/clash-verge-rev) 为交互体验参考，未复制其客户端代码。

目前为公开开发仓库；正式开源许可证将在引入内核与发布正式版本前确定。依赖保留各自许可。

# Hotaru · 蛍（Flutter 原生工程）

本目录为 Hotaru 的正式跨平台客户端工程（Flutter 3.47.8 / Dart 3.13.7），优先面向 Windows 10/11 x64，后续覆盖 Android 与 Linux。

## 目录结构
- `lib/main.dart`：应用入口、深色萤光主题与桌面 Mihomo 内核诊断页（`CorePage`，支持返回导航与退出时自动停止内核并清理临时目录）。
- `lib/dashboard.dart`：小组件桌面首页（支持添加、移除、拖动排序、恢复默认与原子文件持久化）及网络工具箱页。
- `lib/core/mihomo_controller.dart`：桌面 Mihomo 进程控制器（控制端口冲突自动回退分配、配置 `-t` 校验、启动、随机密钥 `/version` 健康检查、取消/停止与清理）。
- `lib/profiles/importer.dart`：Mihomo YAML/JSON（显式 `proxies`）及单节点 URI（SOCKS5、HTTP/HTTPS、基础 Trojan）解析器，以及带超时和 2 MiB 限制的 HTTPS 订阅获取。
- `lib/profiles/import_page.dart`：订阅与节点导入预览界面（仅内存结构校验，不保存凭据、不启用代理）。
- `tool/core_smoke.dart`：使用本机真实 Mihomo 二进制执行的命令行冒烟测试脚本。

## 验证与构建
```sh
flutter pub get
dart format lib test tool
flutter analyze
flutter test
flutter build windows --release
```

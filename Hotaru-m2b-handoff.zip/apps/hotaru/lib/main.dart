import 'dart:async';
import 'dart:io';
import 'dart:ui' show AppExitResponse;

import 'package:flutter/material.dart';

import 'core/mihomo_controller.dart';
import 'dashboard.dart';
import 'profiles/import_page.dart';

void main() => runApp(const HotaruApp());

class HotaruApp extends StatelessWidget {
  const HotaruApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Hotaru · 蛍',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      colorScheme: ColorScheme.fromSeed(
        seedColor: const Color(0xffc7e9a3),
        brightness: Brightness.dark,
      ),
      useMaterial3: true,
    ),
    home: const Dashboard(diagnostic: CorePage()),
  );
}

class CorePage extends StatefulWidget {
  final MihomoController? controller;
  const CorePage({super.key, this.controller});
  @override
  State<CorePage> createState() => _CorePageState();
}

class _CorePageState extends State<CorePage> {
  late final MihomoController core = widget.controller ?? MihomoController();
  final path = TextEditingController();
  bool busy = false;
  bool _cleaningUp = false;
  String message = '桌面内核诊断：不启用系统代理、不启用 TUN。';
  Directory? runtime;
  late final AppLifecycleListener lifecycle;
  Timer? monitor;

  @override
  void initState() {
    super.initState();
    monitor = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && !busy && core.status == CoreStatus.failed) {
        setState(() => message = core.error ?? '内核已异常退出');
      }
    });
    lifecycle = AppLifecycleListener(
      onExitRequested: () async {
        await _cleanupResources(disposeController: true);
        return AppExitResponse.exit;
      },
    );
  }

  Future<void> _cleanupResources({required bool disposeController}) async {
    if (_cleaningUp) return;
    _cleaningUp = true;
    try {
      if (disposeController) {
        await core.dispose();
      } else {
        await core.stop();
      }
    } catch (_) {
      /* ignore cleanup errors during teardown */
    } finally {
      final dir = runtime;
      runtime = null;
      if (dir != null) {
        try {
          if (await dir.exists()) {
            await dir.delete(recursive: true);
          }
        } catch (_) {
          /* ignore locked temp dir on exit */
        }
      }
      _cleaningUp = false;
    }
  }

  Future<void> toggle() async {
    setState(() => busy = true);
    try {
      if (core.status == CoreStatus.running) {
        await core.stop();
        message = '内核已停止';
      } else {
        runtime ??= await Directory.systemTemp.createTemp('hotaru-');
        await core.startDiagnostic(path.text.trim(), runtime!, 19090);
        final portInfo = core.activePort != null
            ? '（控制端口 127.0.0.1:${core.activePort}）'
            : '';
        message = '内核健康检查通过$portInfo。当前未开启代理入口，不代表已经代理网络流量。';
      }
    } catch (_) {
      if (core.status == CoreStatus.stopped) {
        message = '内核启动已取消并停止。';
      } else {
        message = core.error ?? '启动失败，请检查内核路径。';
      }
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  void dispose() {
    monitor?.cancel();
    lifecycle.dispose();
    path.dispose();
    unawaited(_cleanupResources(disposeController: widget.controller == null));
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => PopScope(
    canPop: !busy && core.status != CoreStatus.running,
    onPopInvokedWithResult: (didPop, _) async {
      if (didPop) return;
      final navigator = Navigator.of(context);
      await _cleanupResources(disposeController: false);
      if (mounted) {
        setState(() {
          busy = false;
          message = '内核已停止';
        });
        navigator.pop();
      }
    },
    child: Scaffold(
      appBar: AppBar(
        title: const Text('✦ Hotaru · 蛍'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(
              context,
            ).push(MaterialPageRoute<void>(builder: (_) => const ImportPage())),
            child: const Text('导入预览'),
          ),
        ],
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 760),
          child: ListView(
            padding: const EdgeInsets.all(32),
            children: [
              Text(
                '一点微光，自在连接。',
                style: Theme.of(context).textTheme.headlineMedium,
              ),
              const SizedBox(height: 12),
              const Text('开发预览 · Mihomo 桌面适配层'),
              const SizedBox(height: 32),
              TextField(
                controller: path,
                decoration: const InputDecoration(
                  labelText: '本机 Mihomo 可执行文件绝对路径',
                  border: OutlineInputBorder(),
                ),
                enabled: !busy && core.status != CoreStatus.running,
              ),
              const SizedBox(height: 20),
              FilledButton(
                onPressed: busy || Platform.isAndroid ? null : toggle,
                child: Text(
                  busy
                      ? '正在检查…'
                      : core.status == CoreStatus.running
                      ? '停止内核'
                      : '验证并启动诊断内核',
                ),
              ),
              const SizedBox(height: 24),
              Text(message),
              const SizedBox(height: 24),
              const Text(
                '返回上一页或正常退出应用时会自动停止本页启动的诊断内核并清理临时目录。强制终止父进程的 Job Object 清理保障、订阅导入应用与系统网络管理尚待实现。Android VPN 服务尚未实现。',
              ),
            ],
          ),
        ),
      ),
    ),
  );
}

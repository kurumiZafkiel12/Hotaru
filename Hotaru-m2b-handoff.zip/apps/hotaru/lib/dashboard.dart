import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';

import 'profiles/import_page.dart';

class Dashboard extends StatefulWidget {
  final Widget diagnostic;
  final File? storageFile;
  const Dashboard({super.key, required this.diagnostic, this.storageFile});
  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  static const labels = ['连接状态', '实时流量', '当前节点', '出口 IP', '订阅用量', '快捷测速'];
  List<int> cards = [0, 1, 2, 3];
  int page = 0;
  bool editing = false;
  bool loaded = false;
  String? warning;
  Future<void> writes = Future.value();
  int _writeSeq = 0;

  File? get layoutFile {
    if (widget.storageFile != null) return widget.storageFile;
    final base = Platform.isWindows
        ? Platform.environment['APPDATA']
        : Platform.environment['HOME'];
    if (base == null || base.isEmpty) return null;
    return File('$base${Platform.pathSeparator}Hotaru${Platform.pathSeparator}layout-v1.json');
  }

  /// Writes [content] atomically via a temporary sibling file and rename fallback.
  static Future<void> writeAtomically(File target, String content, int seq) async {
    await target.parent.create(recursive: true);
    final temp = File('${target.path}.tmp.$pid.$seq');
    try {
      await temp.writeAsString(content, flush: true);
      try {
        await temp.rename(target.path);
      } on FileSystemException {
        if (await target.exists()) {
          await target.delete();
        }
        await temp.rename(target.path);
      }
    } finally {
      try {
        if (await temp.exists()) {
          await temp.delete();
        }
      } catch (_) {
        /* ignore cleanup errors on temp file */
      }
    }
  }

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final file = layoutFile;
      if (file != null && await file.exists()) {
        final data = jsonDecode(await file.readAsString());
        if (data is List &&
            data.every((v) => v is int && v >= 0 && v < labels.length)) {
          if (mounted) cards = data.cast<int>().toSet().toList();
        } else {
          warning = '布局读取失败，已使用默认布局。';
        }
      }
    } catch (_) {
      warning = '布局读取失败，已使用默认布局。';
    }
    if (mounted) setState(() => loaded = true);
  }

  void save() {
    final snapshot = jsonEncode(cards);
    final seq = ++_writeSeq;
    writes = writes.then((_) async {
      try {
        final file = layoutFile;
        if (file == null) throw const FileSystemException();
        await writeAtomically(file, snapshot, seq);
        if (mounted && warning != null) {
          setState(() => warning = null);
        }
      } catch (_) {
        if (mounted) {
          setState(() => warning = '布局保存失败，当前修改仅在本次运行有效。');
        }
      }
    });
  }

  Widget card(int id) => Container(
    key: ValueKey(id),
    margin: const EdgeInsets.only(bottom: 16),
    padding: const EdgeInsets.all(24),
    decoration: BoxDecoration(
      color: id == 0 ? const Color(0xff293b30) : const Color(0xff202c2e),
      borderRadius: BorderRadius.circular(24),
      border: Border.all(color: const Color(0xff394a41)),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                labels[id],
                style: const TextStyle(color: Color(0xffc7e9a3)),
              ),
            ),
            if (editing)
              IconButton(
                tooltip: '移除${labels[id]}',
                onPressed: () {
                  setState(() => cards.remove(id));
                  save();
                },
                icon: const Icon(Icons.close),
              ),
          ],
        ),
        const SizedBox(height: 18),
        Text(
          ['让连接，轻一点。', '— KB/s', '还没有节点', '待检测', '— GB', '准备好，再出发。'][id],
          style: const TextStyle(fontSize: 26),
        ),
        const SizedBox(height: 12),
        Text(
          [
            '界面预览 · 尚未启用系统代理或 TUN',
            '接入实际代理连接后显示流量',
            '可先在导入预览中检查配置',
            '不会显示模拟 IP 地址',
            '订阅保存与用量统计开发中',
            '延迟与下载测速开发中',
          ][id],
          style: const TextStyle(color: Color(0xffa5b6ad)),
        ),
      ],
    ),
  );

  Widget home() => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Row(
        children: [
          const Expanded(
            child: Text('一点微光，自在连接。', style: TextStyle(fontSize: 28)),
          ),
          TextButton(
            onPressed: loaded ? () => setState(() => editing = !editing) : null,
            child: Text(editing ? '完成' : '自定义'),
          ),
        ],
      ),
      const SizedBox(height: 12),
      const Text('我的桌面 / 可定制小组件', style: TextStyle(color: Color(0xffb0c49d))),
      if (warning != null) Text(warning!),
      if (editing)
        Wrap(
          spacing: 8,
          children: [
            for (var i = 0; i < labels.length; i++)
              if (!cards.contains(i))
                ActionChip(
                  label: Text('＋ ${labels[i]}'),
                  onPressed: () {
                    setState(() => cards.add(i));
                    save();
                  },
                ),
            ActionChip(
              label: const Text('恢复默认'),
              onPressed: () {
                setState(() => cards = [0, 1, 2, 3]);
                save();
              },
            ),
          ],
        ),
      const SizedBox(height: 24),
      Expanded(
        child: !loaded
            ? const Center(child: CircularProgressIndicator())
            : cards.isEmpty
            ? const Center(child: Text('点击自定义，添加你关心的小组件。'))
            : editing
            ? ReorderableListView(
                onReorderItem: (oldIndex, newIndex) {
                  setState(() {
                    final item = cards.removeAt(oldIndex);
                    cards.insert(newIndex, item);
                  });
                  save();
                },
                children: cards.map(card).toList(),
              )
            : ListView(children: cards.map(card).toList()),
      ),
    ],
  );

  Widget toolbox() => ListView(
    children: [
      const Text('网络工具箱', style: TextStyle(fontSize: 28)),
      const SizedBox(height: 24),
      for (final name in ['节点测速', '出口 IP', 'IP 质量', 'DNS 诊断'])
        Card(
          child: ListTile(
            leading: const Icon(Icons.insights),
            title: Text(name),
            subtitle: const Text('等待代理能力接入'),
            trailing: const Chip(label: Text('开发中')),
          ),
        ),
      const SizedBox(height: 20),
      FilledButton.tonal(
        onPressed: () => Navigator.of(context)
            .push(MaterialPageRoute<void>(builder: (_) => widget.diagnostic)),
        child: const Text('打开内核诊断'),
      ),
    ],
  );

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xff111a1c),
    appBar: AppBar(
      title: const Text('✦ Hotaru · 蛍'),
      actions: const [
        Padding(padding: EdgeInsets.all(16), child: Text('界面预览 v0.1')),
      ],
    ),
    body: Padding(
      padding: const EdgeInsets.all(24),
      child: page == 0
          ? home()
          : page == 1
          ? toolbox()
          : const ImportPage(),
    ),
    bottomNavigationBar: NavigationBar(
      selectedIndex: page,
      onDestinationSelected: (v) => setState(() => page = v),
      destinations: const [
        NavigationDestination(
          icon: Icon(Icons.dashboard_outlined),
          label: '桌面',
        ),
        NavigationDestination(icon: Icon(Icons.widgets_outlined), label: '工具箱'),
        NavigationDestination(icon: Icon(Icons.download_outlined), label: '导入'),
      ],
    ),
  );
}

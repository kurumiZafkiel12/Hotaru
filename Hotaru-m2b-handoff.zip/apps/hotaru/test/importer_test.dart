import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:hotaru/profiles/importer.dart';

void main() {
  const yaml =
      'proxies:\n  - {name: sample, type: socks5, server: localhost, port: 1080}\nrules: [MATCH,DIRECT]';

  test('two modes preserve or strip surrounding config', () {
    expect(
      ProfileImporter.parse(
        yaml,
        ImportMode.fullConfig,
      ).config.containsKey('rules'),
      true,
    );
    expect(ProfileImporter.parse(yaml, ImportMode.nodesOnly).config.keys, [
      'proxies',
    ]);
  });

  test('URI decodes credentials and IPv6', () {
    final n =
        (ProfileImporter.parse(
                  'socks5://u:p%40ss@[::1]:1080#test',
                  ImportMode.nodesOnly,
                ).config['proxies']
                as List)
            .single;
    expect(n['password'], 'p@ss');
    expect(n['server'], '::1');
    expect(n['port'], 1080);
  });

  test(
    'reject malformed, duplicate, unsupported parameters and huge input',
    () {
      for (final s in [
        '',
        'proxies: []',
        'socks5://host:0',
        'socks5://:pass@host:1080',
        'socks5://user:@host:1080',
        'socks5://host:1080?#test',
        'socks5://host:1080#%20',
        'trojan://@host:443',
        'trojan://user:pass@host:443',
        'trojan://pw@host:443?sni=',
        'trojan://pw@host:443?allowInsecure=1',
        'ss://YWVzLTI1Ni1nY206cGFzcw==@host:8388#unsupported',
        'socks5://host:1080\nsocks5://host:1080',
        'a' * (ProfileImporter.maxBytes + 1),
      ]) {
        expect(
          () => ProfileImporter.parse(s, ImportMode.nodesOnly),
          throwsFormatException,
          reason: 'Expected FormatException for input: $s',
        );
      }
    },
  );

  test(
    'HTTPS subscription policy rejects insecure input before networking',
    () async {
      await expectLater(
        ProfileImporter.fetch(Uri.parse('http://localhost/sub')),
        throwsFormatException,
      );
      await expectLater(
        ProfileImporter.fetch(Uri.parse('https://user:pass@example.com/sub')),
        throwsFormatException,
      );
    },
  );

  test(
    'controlled loopback subscription enforces 200 status, no redirect, and 2 MiB cap',
    () async {
      final server = await HttpServer.bind(InternetAddress.loopbackIPv4, 0);
      addTearDown(() => server.close(force: true));
      server.listen((request) async {
        if (request.uri.path == '/ok') {
          request.response.statusCode = 200;
          request.response.write('socks5://127.0.0.1:1080#loopback');
          await request.response.close();
        } else if (request.uri.path == '/redirect') {
          request.response.statusCode = 302;
          request.response.headers.set(HttpHeaders.locationHeader, '/ok');
          await request.response.close();
        } else if (request.uri.path == '/huge') {
          request.response.statusCode = 200;
          request.response.add(List.filled(ProfileImporter.maxBytes + 16, 65));
          await request.response.close();
        }
      });

      final base = 'http://127.0.0.1:${server.port}';
      final body = await ProfileImporter.fetch(
        Uri.parse('$base/ok'),
        allowLoopbackHttpForTest: true,
      );
      expect(body, contains('socks5://127.0.0.1:1080#loopback'));

      await expectLater(
        ProfileImporter.fetch(
          Uri.parse('$base/redirect'),
          allowLoopbackHttpForTest: true,
        ),
        throwsFormatException,
      );

      await expectLater(
        ProfileImporter.fetch(
          Uri.parse('$base/huge'),
          allowLoopbackHttpForTest: true,
        ),
        throwsFormatException,
      );
    },
  );
}

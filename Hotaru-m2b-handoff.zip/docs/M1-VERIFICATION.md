# M1：正式工程与内核适配

## 范围
- Flutter 3.47.8 / Dart 3.13.7，Windows、Android、Linux 平台工程。
- 原生界面已集成小组件桌面首页（`Dashboard`）、工具箱、导入预览（`ImportPage`）与桌面内核诊断页（`CorePage`）。
- 桌面 CoreAdapter（`MihomoController`）：控制端口可用性检测与冲突自动回退、配置校验、子进程启动、随机认证密钥、回环健康检查、启动期取消、页面返回/销毁/退出自动停止与临时文件清理。
- Android 禁用桌面内核启动入口；未实现 VpnService。

## 本机真实内核验证
使用官方 Mihomo v1.19.33 Windows amd64 compatible ZIP。
SHA256：`7aaf636a4f2172dcd8ec34ac4f52797b059195e5afd6409508c963e545f8864d`。
二进制只用于本地验证，未加入仓库或构建产物。

```powershell
dart run tool/core_smoke.dart C:/absolute/path/mihomo.exe
```

已通过配置校验、启动、带认证的 `/version` 健康检查、停止。诊断配置关闭代理入口、TUN、DNS 劫持，不改变用户系统代理。

## 运行
```sh
cd apps/hotaru
flutter pub get
flutter analyze
flutter test
flutter run -d windows
```
Windows 编译需要 Visual Studio 的 Desktop development with C++ 工作负载。CI 配置执行 Windows 编译，并自动打包发布预览 ZIP；产物不包含 Mihomo，不是完整代理客户端。

## 已知限制与下一步
- 页面返回导航、组件销毁与桌面正常退出回调均会主动停止内核并清理临时目录；强制结束父进程（如 `taskkill /F`）尚无 Windows Job Object 保障。
- 诊断控制端口优先使用 19090，占用时自动分配空闲回环端口；正式代理配置管理尚待接入。
- 订阅持久化、系统代理、TUN、测速仍未接入。
- macOS 不属于当前交付平台；Android/Linux 平台目录已生成，但未实机验证。
- 尚未签名；原生图标仍是 Flutter 默认图标，正式发布前替换。
